#!/usr/bin/env python3
"""Cross-platform editable OOXML renderer for science_hu geometry caches.

Windows keeps the live COM renderer. This renderer exists for macOS and for
headless validation where PowerPoint COM is unavailable. It appends native
custom-geometry shapes and text boxes to a PPTX without raster fallback.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import tempfile
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.oxml import parse_xml
from pptx.oxml.ns import nsdecls
from pptx.util import Emu, Pt


EMU_PER_PT = 12700.0


def esc(value: str) -> str:
    return (
        value.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def same(a: list[float], b: list[float]) -> bool:
    return abs(a[0] - b[0]) < 1e-6 and abs(a[1] - b[1]) < 1e-6


def rgb_hex(value: list[int] | None, fallback: str = "000000") -> str:
    if not value:
        return fallback
    return "".join(f"{max(0, min(255, int(v))):02X}" for v in value[:3])


def alpha_xml(opacity: float) -> str:
    alpha = max(0, min(100000, round(float(opacity) * 1000)))
    return f'<a:alpha val="{alpha}"/>' if alpha < 100000 else ""


def map_point(point, scale, offset_x, offset_y, view_x, view_y):
    return (
        offset_x + (float(point[0]) - view_x) * scale,
        offset_y + (float(point[1]) - view_y) * scale,
    )


def add_freeform(slide, subpath, paint, name, shape_id, transform):
    scale, offset_x, offset_y, view_x, view_y = transform
    source_paths = subpath.get("subpaths") or [subpath]
    mapped_paths = []
    for source in source_paths:
        mapped = [{key: map_point(point[key], scale, offset_x, offset_y, view_x, view_y)
                   for key in ("a", "l", "r")} for point in source["points"]]
        if mapped:
            mapped_paths.append((source, mapped))
    mapped = [point for _, points in mapped_paths for point in points]
    all_xy = [coord for point in mapped for key in ("a", "l", "r") for coord in [point[key]]]
    min_x = min(p[0] for p in all_xy)
    min_y = min(p[1] for p in all_xy)
    max_x = max(p[0] for p in all_xy)
    max_y = max(p[1] for p in all_xy)
    width = max(max_x - min_x, 1.0 / EMU_PER_PT)
    height = max(max_y - min_y, 1.0 / EMU_PER_PT)

    off_x, off_y = round(min_x * EMU_PER_PT), round(min_y * EMU_PER_PT)
    ext_x, ext_y = max(1, round(width * EMU_PER_PT)), max(1, round(height * EMU_PER_PT))

    def local(point):
        return (
            min(ext_x, max(0, round((point[0] - min_x) * EMU_PER_PT))),
            min(ext_y, max(0, round((point[1] - min_y) * EMU_PER_PT))),
        )

    commands = []
    for source, mapped in mapped_paths:
        first_x, first_y = local(mapped[0]["a"])
        commands.append(f'<a:moveTo><a:pt x="{first_x}" y="{first_y}"/></a:moveTo>')
        for idx in range(1, len(mapped)):
            previous = mapped[idx - 1]
            current = mapped[idx]
            end_x, end_y = local(current["a"])
            if same(previous["r"], previous["a"]) and same(current["l"], current["a"]):
                commands.append(f'<a:lnTo><a:pt x="{end_x}" y="{end_y}"/></a:lnTo>')
            else:
                c1x, c1y = local(previous["r"])
                c2x, c2y = local(current["l"])
                commands.append(
                    f'<a:cubicBezTo><a:pt x="{c1x}" y="{c1y}"/>'
                    f'<a:pt x="{c2x}" y="{c2y}"/><a:pt x="{end_x}" y="{end_y}"/></a:cubicBezTo>'
                )
        if source.get("closed"):
            previous = mapped[-1]
            current = mapped[0]
            if not (same(previous["r"], previous["a"]) and same(current["l"], current["a"])):
                c1x, c1y = local(previous["r"])
                c2x, c2y = local(current["l"])
                commands.append(
                    f'<a:cubicBezTo><a:pt x="{c1x}" y="{c1y}"/>'
                    f'<a:pt x="{c2x}" y="{c2y}"/><a:pt x="{first_x}" y="{first_y}"/></a:cubicBezTo>'
                )
            commands.append("<a:close/>")

    fill = "<a:noFill/>"
    if paint.get("filled") and any(source.get("closed") for source, _ in mapped_paths):
        fill = (
            f'<a:solidFill><a:srgbClr val="{rgb_hex(paint.get("fillColor"))}">'
            f'{alpha_xml(paint.get("opacity", 100))}</a:srgbClr></a:solidFill>'
        )
    line = '<a:ln><a:noFill/></a:ln>'
    if paint.get("stroked"):
        weight = max(3175, round(float(paint.get("strokeWidth", 1)) * scale * EMU_PER_PT))
        line = (
            f'<a:ln w="{weight}"><a:solidFill><a:srgbClr val="{rgb_hex(paint.get("strokeColor"))}">'
            f'{alpha_xml(paint.get("opacity", 100))}</a:srgbClr></a:solidFill></a:ln>'
        )
    xml = f'''<p:sp {nsdecls("a", "p")}>
      <p:nvSpPr><p:cNvPr id="{shape_id}" name="{esc(name)}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
      <p:spPr>
        <a:xfrm><a:off x="{off_x}" y="{off_y}"/><a:ext cx="{ext_x}" cy="{ext_y}"/></a:xfrm>
        <a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="l" t="t" r="r" b="b"/>
          <a:pathLst><a:path w="{ext_x}" h="{ext_y}">{''.join(commands)}</a:path></a:pathLst>
        </a:custGeom>{fill}{line}
      </p:spPr>
      <p:txBody><a:bodyPr/><a:lstStyle/><a:p/></p:txBody>
    </p:sp>'''
    slide.shapes._spTree.insert_element_before(parse_xml(xml), "p:extLst")


def font_signature(text):
    weight = str(text.get("fontWeight", "")).strip().lower()
    family = str(text.get("fontFamily") or "Arial")
    bold = weight == "bold" or (weight.isdigit() and int(weight) >= 600)
    italic = str(text.get("fontStyle", "")).lower() == "italic"
    return family, bold, italic


def slide_layout(view_box, existing_deck=None):
    """Return slide dimensions and the figure fit shared by export and preview."""
    view_x, view_y, view_width, view_height = map(float, view_box)
    if existing_deck is not None:
        slide_width = existing_deck.slide_width / EMU_PER_PT
        slide_height = existing_deck.slide_height / EMU_PER_PT
    else:
        slide_width, slide_height = 960.0, 960.0 * view_height / view_width
    margin = 18.0 if existing_deck is not None else 0.0
    scale = min((slide_width - 2*margin)/view_width, (slide_height - 2*margin)/view_height)
    if scale <= 0:
        raise ValueError("The selected slide is too small for the artwork.")
    offset_x = (slide_width - view_width * scale) / 2
    offset_y = (slide_height - view_height * scale) / 2
    return (slide_width, slide_height), (scale, offset_x, offset_y, view_x, view_y)


def add_text(slide, atom, transform, baselines=None):
    scale, offset_x, offset_y, view_x, view_y = transform
    text = atom["text"]
    x, y = map_point(text["position"], scale, offset_x, offset_y, view_x, view_y)
    size = max(4.0, float(text["fontSize"]) * scale)
    width = max(size * 2.0, size * len(str(text["contents"])) * 0.7)
    height = size * 1.5
    anchor = str(text.get("textAnchor") or "start").lower()
    if anchor == "middle":
        x -= width / 2.0
    elif anchor == "end":
        x -= width
    family, bold, italic = font_signature(text)
    baseline_adjustment = (baselines or {}).get((family, bold, italic), 0) * size
    top = y - size * 1.05 + baseline_adjustment
    rotation = float(text.get("rotationDegrees", 0))
    if rotation:
        # Office rotates about the box centre; SVG rotates about the text anchor.
        anchor_x, anchor_y = map_point(text["position"], scale, offset_x, offset_y, view_x, view_y)
        dx, dy = x + width / 2 - anchor_x, top + height / 2 - anchor_y
        angle = math.radians(rotation)
        x = anchor_x + dx * math.cos(angle) - dy * math.sin(angle) - width / 2
        top = anchor_y + dx * math.sin(angle) + dy * math.cos(angle) - height / 2
    shape = slide.shapes.add_textbox(
        Emu(round(x * EMU_PER_PT)),
        Emu(round(top * EMU_PER_PT)),
        Emu(round(width * EMU_PER_PT)),
        Emu(round(height * EMU_PER_PT)),
    )
    shape.name = atom["objectName"]
    frame = shape.text_frame
    frame.clear()
    frame.margin_left = frame.margin_right = frame.margin_top = frame.margin_bottom = 0
    frame.word_wrap = False
    paragraph = frame.paragraphs[0]
    paragraph.alignment = {"middle": PP_ALIGN.CENTER, "end": PP_ALIGN.RIGHT}.get(anchor, PP_ALIGN.LEFT)
    run = paragraph.add_run()
    run.text = str(text["contents"])
    font = run.font
    font.name, font.size = family, Pt(size)
    font.bold, font.italic = bold, italic
    font.color.rgb = RGBColor(*[int(v) for v in text.get("fillColor", [0, 0, 0])])
    opacity = max(0, min(100000, round(float(text.get("opacity", 100)) * 1000)))
    props = run._r.get_or_add_rPr()
    if opacity < 100000:
        rgb = props.find(".//{http://schemas.openxmlformats.org/drawingml/2006/main}srgbClr")
        if rgb is not None:
            rgb.append(parse_xml(f'<a:alpha {nsdecls("a")} val="{opacity}"/>'))
    spacing = round(float(text.get("letterSpacing", 0)) * scale * 100)
    if spacing:
        props.set("spc", str(max(-400000,min(400000,spacing))))
    shape.rotation = rotation


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--geometry-cache", required=True, type=Path)
    parser.add_argument("--output-pptx", required=True, type=Path)
    parser.add_argument("--input-pptx", type=Path)
    parser.add_argument("--slide-index", type=int, default=0, help="1-based existing slide; 0 appends a blank slide")
    parser.add_argument("--font-baselines", type=Path)
    args = parser.parse_args()
    baselines = {}
    if args.font_baselines:
        measured = json.loads(args.font_baselines.read_text(encoding="utf-8"))
        baselines = {tuple(font["style"]): font["offset_per_point"] for font in measured["fonts"]}
    cache = json.loads(args.geometry_cache.read_text(encoding="utf-8"))
    if int(cache.get("schema_version", 0)) != 3:
        raise SystemExit("Unsupported geometry cache schema")
    if any("sourceSubpathIndex" in atom for atom in cache.get("atoms", [])):
        raise SystemExit("REBUILD_CACHE_REQUIRED: legacy cache split compound contours; rebuild from the original SVG")
    prs = Presentation(str(args.input_pptx)) if args.input_pptx else Presentation()
    size, transform = slide_layout(cache["view_box"], prs if args.input_pptx else None)
    if not args.input_pptx:
        prs.slide_width, prs.slide_height = (round(value*EMU_PER_PT) for value in size)
    if args.slide_index:
        if not 1 <= args.slide_index <= len(prs.slides):
            raise SystemExit("slide-index is out of range")
        slide = prs.slides[args.slide_index - 1]
    else:
        slide = prs.slides.add_slide(prs.slide_layouts[6])

    next_id = max((shape.shape_id for shape in slide.shapes), default=1) + 1
    created = 0
    for batch in cache["batches"]:
        for atom_index in batch["atom_indices"]:
            atom = cache["atoms"][int(atom_index)]
            if atom["kind"] == "text":
                add_text(slide, atom, transform, baselines)
                created += 1
                next_id += 1
            elif atom["kind"] == "path":
                paths = [path for path in atom.get("subpaths", []) if len(path.get("points", [])) >= 2]
                if not paths:
                    continue
                for paint_index, paint in enumerate(atom.get("paintParts") or [{}]):
                    if paint.get("filled") and paint.get("fillRule", "nonzero") != "nonzero":
                        raise ValueError("Even-odd compound fill requires winding normalization before PPT export")
                    add_freeform(slide, {"subpaths": paths}, paint,
                                 f'{atom["objectName"]}_PAINT_{paint_index:03d}', next_id, transform)
                    created += 1
                    next_id += 1

    args.output_pptx.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary_name = tempfile.mkstemp(
        prefix=f".{args.output_pptx.stem}-",
        suffix=".pptx",
        dir=args.output_pptx.parent,
    )
    os.close(handle)
    temporary = Path(temporary_name)
    try:
        prs.save(str(temporary))
        Presentation(str(temporary))
        os.replace(temporary, args.output_pptx)
    finally:
        if temporary.exists():
            temporary.unlink()
    reopened = Presentation(str(args.output_pptx))
    print(json.dumps({
        "ok": True,
        "backend": "editable-ooxml",
        "output_pptx": str(args.output_pptx.resolve()),
        "slide_index": args.slide_index or len(reopened.slides),
        "native_object_count": created,
        "slide_count": len(reopened.slides),
    }, ensure_ascii=False, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
